
<!DOCTYPE html>
<!--=== Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="{{asset('SRstyle.css')}}">
     
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <title>New Student Regisration Form </title> 
</head>
<body>
    <div class="container">
        <header>Registration</header>

        <form action="{{route('Studentregs')}}" method="POST">
            @csrf
            <div class="form first">
                <div class="details personal">
                    <span class="title">Student Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label> Student Full Name</label>
                            <input id="StudentName" type="text" placeholder="Enter student name" required name="StudentName">
                        </div>

                        <div class="input-field">
                            <label>Age</label>
                            <input id="StudentAge" type="text" placeholder="Enter student age" required name="StudentAge">
                        </div>


                        <div class="input-field">
                            <label>Balance</label>
                            <input id="Balance" type="number" placeholder="Enter balance" required name="Balance">
                        </div>

                        
                    </div>
                </div>

                <div class="details ID">
                    <span class="title">Parents Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label>Father Full Name</label>
                            <input id="FatherName"type="text" placeholder="Enter father name" required name="FatherName">
                        </div>

                        <div class="input-field">
                            <label>Father Email</label>
                            <input id="FatherEmail"type="email" placeholder="Enter father email" required name="FatherEmail">
                        </div>

                        <div class="input-field">
                            <label>Father Password</label>
                     <input style = "background-color:silver"id="FatherPassword" type="password" value="*********" placeholder=" father password" required name="FatherPassword" readonly>
                        </div>

                       

                        <div class="input-field">
                            <label>Payment number</label>
                            <input id="PaymentNo" type="password" placeholder="Scan" required name="PaymentNo">
                        </div>


                       

                    <button class="sumbit">
                            <span class="btnText">Submit</span>
                           
                        </button>
                </div> 
            </div>
                        
                       
                   
               
            
        </form>
    </div>

    <script src="{{asset('SRscript.js')}}"></script>
</body>
</html>