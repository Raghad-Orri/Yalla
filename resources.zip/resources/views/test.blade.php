<div class="mt-2 text-gray-600 dark:text-gray-400 text-sm">
                                    OUR PROJECT has wonderful documentation covering every aspect of the framework. Whether you are a newcomer or have prior experience with Laravel, we recommend reading our documentation from beginning to end.
                                    </div>