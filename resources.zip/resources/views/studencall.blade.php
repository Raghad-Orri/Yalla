

<!DOCTYPE html>
<html>
<head>
   <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('School', 'School') }}</title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=Nunito" rel="stylesheet">

    <!-- Scripts -->
@vite(['resources/sass/app.scss','resources/js/app.js'])

</head>
<body>


<style>
       .container {
           display: flex;
           flex-wrap: wrap;
           justify-content: space-between;
           max-width: 960px; /* Adjust as needed */ 
           margin: 0 auto;
}
        .card {
           flex: 0 0 calc (33.33% - 20px); /* Adjust as needed */ 
           margin-bottom: 20px;
           border: 1px solid #ccc;
           border-radius: 5px;
           padding: 10px;
           box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
           transition: box-shadow 0.3s ease-in-out; 
           background-color: lightblue;
        }

        .card1 {
         flex: 0 0 calc(33.33% -20px); /* Adjust as needed */
         margin-bottom: 20px;
         border: 1px solid #ccc;
         border-radius: 5px;
         padding: 10px;
         box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1); 
         transition: box-shadow 0.3s ease-in-out;
        background-color: lightsalmon;


}




    .card:hover {
        box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
    }
    .card h2 {
         margin-top: 0;
    }
    .card p {
        margin-bottom: 0;
    }

    </style>

    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
            <div class="container">
                <a class="navbar-brand" href="{{ url('/') }}">
                {{ config('YALLA', 'YALLA') }}
                </a>

                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                   <span class="navbar-toggler-icon"></span>
                </button>

            </div>
        </nav>
        <br> 
        <br>
        <ul class="container" id="itemList">
        <!-- Items will be dynamically added here --> 
    </ul>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function() {
        fetchItems();
        setInterval(fetchItems, 500);
});

function fetchItems() {
$.ajax({
url: 'https://ragorr.dreamhosters.com/public/studentCall',
 type: 'GET',
success: function (response) {
var items = response;
$('#itemList').empty(); // Clear existing items
$.each(items, function (index, item) {
var NAME = item.hasOwnProperty('NAME') ?item.NAME: '';
var calltime = item.hasOwnProperty( 'updated_at') ? item.updated_at : ''; 
const d = new Date();


var dt1 = new Date(calltime).getTime();
var dt2 = d.getTime();


var diff = (dt2-dt1)/ 1000;
var diffh = Math.abs (Math.round(diff/3600));
var diffm = Math.abs (Math.round(diff/60));

if (diffm <= 5) {var card = '<div class="card">';}
else {var card = '<div class="card1">'; }


var lt = (parseFloat(calltime.slice(11,13)) + 3 )  ;
var tf = calltime.slice(13,16) ;

if(lt > 12) {lt = lt -12}
                        
card += '<h2>' + NAME + '</h2>';
card += '<p>' +  "call time "  + lt + tf + '</p>';
                  
card += '</div>'; 
$('#itemList').append(card);
});
},
error: function (xhr, status, error) {
console.error(xhr.responseText);
}
});
}
</script>
</div>
</body>
 </html>