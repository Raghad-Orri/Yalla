<!DOCTYPE html>
<!--=== Coding by CodingLab | www.codinglabweb.com === -->
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    <link rel="stylesheet" href="{{asset('SRstyle.css')}}">
     
    <!----===== Iconscout CSS ===== -->
    <link rel="stylesheet" href="https://unicons.iconscout.com/release/v4.0.0/css/line.css">

    <title>Teacher Regisration Form </title> 
</head>
<body>
    <div class="container">
        <header>Registration</header>

        <form action="{{route('teacheregs')}}" method="POST">
            @csrf
            <div class="form first">
                <div class="details personal">
                    <span class="title">Teacher Details</span>

                    <div class="fields">
                        <div class="input-field">
                            <label> Teacher Full Name</label>
                            <input id="Name" type="text" placeholder="Enter Teacher name" required name="Name">
                        </div>

                        <div class="input-field">
                            <label>Teacher role</label>
                            <input id="Role" type="text" placeholder="Enter Teacher role" required name="Role">
                        </div>


                        <div class="input-field">
                            <label>Email</label>
                            <input id="Email" type="email" placeholder="Enter Teacher Email" required name="Email">
                        </div>

                        
                    </div>
                </div>

                <div class="details ID">
                    

                    <div class="fields">
                        <div class="input-field">
                            <label>Mobile number</label>
                            <input id="Mobile"type="phone"  placeholder="Mobile" required name="Mobile">
                        </div>

                    
                        <div class="input-field">
                            <label> Password</label>
                            <input style = "background-color:silver"id="Password" type="text" value="*********" placeholder="Password" required name="Password" readonly>
                        </div>

                       

                    <button class="sumbit">
                            <span class="btnText">Submit</span>
                           
                        </button>
                </div> 
            </div>
                        
                       
                   
               
            
        </form>
    </div>

    <script src="{{asset('SRscript.js')}}"></script>
</body>
</html>