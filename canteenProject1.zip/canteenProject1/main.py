import tkinter as tk
from tkinter import simpledialog, messagebox
import customtkinter
from threading import Timer
import requests



class CanteenCashierApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Canteen Cashier")
        #self.master.attributes('-fullscreen',True)
        self.master.geometry('800x600')
        
    
        
        self.picked_items = {}
        self.total_price = 0
        
        # Create widgets
        self.create_widgets()
    
    def create_widgets(self):
        

                
       # Drinks
       
       
       
        Milk = customtkinter.CTkButton(self.master,text="Milk 2$",width=150, height=120 ,  font=("Arial", 18), border_width=0,corner_radius=20, command=lambda  i="Milk", t="Drinkes", p=2.0: self.add_item(i, t, p))
        Milk.place(relx=0.01, rely=0.02)
        Milk_r = customtkinter.CTkButton(self.master,text="-",width=100, height=120 , fg_color=("red3"),  font=("Arial", 25), border_width=0,corner_radius=8, command=lambda  i="Milk", t="Drinkes", p=2.0: self.remove_item(i, t, p))
        Milk_r.place(relx=0.145, rely=0.02)
        
        
        Juice = customtkinter.CTkButton(self.master,text="Juice 2$",width=150, height=120 ,  font=("Arial", 18), border_width=0,corner_radius=20, command=lambda  i="Juice", t="Drinkes", p=2.0: self.add_item(i, t, p))
        Juice.place(relx=0.25, rely=0.02)
        Juice_r = customtkinter.CTkButton(self.master,text="-",width=100, height=120 , fg_color=("red"),  font=("Arial", 25), border_width=0,corner_radius=8, command=lambda  i="Juice", t="Drinkes", p=2.0: self.remove_item(i, t, p))
        Juice_r.place(relx=0.385, rely=0.02)
        
        
        SUNTOP = customtkinter.CTkButton(self.master,text="SunTop 2$",width=150, height=120 ,  font=("Arial", 18), border_width=0,corner_radius=20, command=lambda  i="Suntop", t="Drinkes", p=2: self.add_item(i, t, p))
        SUNTOP.place(relx=0.5, rely=0.02)
        
        SUNTOP_r = customtkinter.CTkButton(self.master,text="-",width=100, height=120 , fg_color=("red"),  font=("Arial", 25), border_width=0,corner_radius=8, command=lambda  i="Suntop", t="Drinkes", p=2: self.remove_item(i, t, p))
        SUNTOP_r.place(relx=0.635, rely=0.02)
        
        
        Water = customtkinter.CTkButton(self.master,text="Water 1$",width=150, height=120 ,  font=("Arial", 18), border_width=0,corner_radius=20, command=lambda  i="Water", t="Drinkes", p=1: self.add_item(i, t, p))
        Water.place(relx=0.765, rely=0.02)
        
        Water_r = customtkinter.CTkButton(self.master,text="-",width=100, height=120 , fg_color=("red"),  font=("Arial", 25), border_width=0,corner_radius=8, command=lambda  i="Water", t="Drinkes", p=1: self.remove_item(i, t, p))
        Water_r.place(relx=0.9, rely=0.02)
        
        # Snaks
        croissant = customtkinter.CTkButton(self.master,text="Croissant 3$",width=150, height=120 ,  font=("Arial", 18), border_width=0,corner_radius=20, command=lambda  i="croissant", t="Snaks", p=3: self.add_item(i, t, p))
        croissant.place(relx=0.01, rely=0.25)
        croissant_r = customtkinter.CTkButton(self.master,text="-",width=100, height=120 , fg_color=("red"),  font=("Arial", 25), border_width=0,corner_radius=8, command=lambda   i="croissant", t="Snaks", p=3: self.remove_item(i, t, p))
        croissant_r.place(relx=0.145, rely=0.25)
       
        
        Sandwich = customtkinter.CTkButton(self.master,text=" Sandwich 4$",width=100, height=120 ,  font=("Arial", 18), border_width=0,corner_radius=20, command=lambda  i="Sandwich", t="Snaks", p=4: self.add_item(i, t, p))
        Sandwich.place(relx=0.25, rely=0.25)
        Sandwich_r = customtkinter.CTkButton(self.master,text="-",width=100, height=120 , fg_color=("red"),  font=("Arial", 25), border_width=0,corner_radius=8, command=lambda  i="Sandwich", t="Snaks", p=4: self.remove_item(i, t, p))
        Sandwich_r.place(relx=0.385, rely=0.25)
        
        
        
        Chocolate = customtkinter.CTkButton(self.master,text=" Chocolate 2$",width=100, height=120 ,  font=("Arial", 18), border_width=0,corner_radius=20, command=lambda  i=" Chocolate", t="Snaks", p=2: self.add_item(i, t, p))
        Chocolate.place(relx=0.5,  rely=0.25)
        Chocolate = customtkinter.CTkButton(self.master,text="-",width=100, height=120 , fg_color=("red"),  font=("Arial", 25), border_width=0,corner_radius=8, command=lambda  i=" Chocolate", t="Snaks", p=2: self.remove_item(i, t, p))
        Chocolate.place(relx=0.635,  rely=0.25)
        
        
        chips = customtkinter.CTkButton(self.master,text="Chips 2$",width=150, height=120 ,  font=("Arial", 18), border_width=0,corner_radius=20, command=lambda  i="chips", t="Snaks", p=2.0: self.add_item(i, t, p))
        chips.place(relx=0.765, rely=0.25)
        chips_r = customtkinter.CTkButton(self.master,text="-",width=100, height=120 , fg_color=("red"),  font=("Arial", 25), border_width=0,corner_radius=8, command=lambda  i="chips", t="Snaks", p=2.0: self.remove_item(i, t, p))
        chips_r.place(relx=0.9, rely=0.25)
        
        
        Tea = customtkinter.CTkButton(self.master,text="Tea 1$",width=150, height=120 ,  font=("Arial", 18), border_width=0,corner_radius=20, command=lambda  i="Tea", t="Hot Drinkes", p=1.0: self.add_item(i, t, p))
        Tea.place(relx=0.01, rely=0.48)
        Tea_r = customtkinter.CTkButton(self.master,text="-",width=100, height=120 , fg_color=("red"),  font=("Arial", 25), border_width=0,corner_radius=8, command=lambda  i="Tea", t="Hot Drinkes", p=1.0: self.remove_item(i, t, p))
        Tea_r.place(relx=0.145, rely=0.48)
        
        
    
        
        # Button to finish order
        finish_frame = tk.Frame(self.master)
        finish_frame.place(relx=0.8, rely=0.9)
        self.finish_button = customtkinter.CTkButton(finish_frame, text="Pay", font=("Arial", 35), border_width=0,corner_radius=8,   command=self.finish_order)
        self.finish_button.pack(padx=5)
        
        # Label to display total price and picked items
        self.total_label = tk.Label(self.master, text="Total: $0\nPicked Items: ", font=('Helvetica', 15))
        self.total_label.place(relx=0.45, rely=0.7)
    
    def add_item(self, item, item_type, price):
        if item_type not in self.picked_items:
            self.picked_items[item_type] = {}
        if item not in self.picked_items[item_type]:
            self.picked_items[item_type][item] = 0
        self.picked_items[item_type][item] += 1
        self.total_price += round(price)
        self.update_total_label()
    
    def remove_item(self, item, item_type, price):
        if item_type in self.picked_items and item in self.picked_items[item_type]:
            if self.picked_items[item_type][item] > 0:
                self.picked_items[item_type][item] -= 1
                self.total_price -= round(price)
                self.update_total_label()
    
    def update_total_label(self):
        # Update total price
        self.total_label.config(text="Total: $" + str(self.total_price))
        
        # Update picked items
        picked_text = "Picked Items:\n"
        for item_type, items in self.picked_items.items():
            for item, quantity in items.items():
                if quantity > 0:
                    picked_text += f"{item_type} - {item} ({quantity})\n"
        self.total_label.config(text="Total: $" + str(self.total_price) + "\n" + picked_text)
    
    def finish_order(self):
        # Get user's number
        user_number = simpledialog.askstring("payment", "Please scan Your device:" ,)
        if user_number is not None:
            # Send a POST request
            self.send_payment_request(self.total_price, user_number)
            # Reset the interface
            self.reset_interface()
    
    def send_payment_request(self, total, number):
        url = "https://ragorr.dreamhosters.com/public/api/payment"
        data = {"total": total, "paymentNo": number}
        try:
            response = requests.post(url, data=data)
            # Show the response
            messagebox.showinfo("Payment Response", response.text)
        except Exception as e:
            messagebox.showerror("Error", f"An error occurred: {e}")
    
    def reset_interface(self):
        # Reset picked items and total price
        self.picked_items = {}
        self.total_price = 0
        
        # Update total label
        self.update_total_label()

def main():
    root = tk.Tk()
    app = CanteenCashierApp(root)
    root.mainloop()

if __name__ == "__main__":
    main()
